#include "helper_functions.h"
using namespace std;

void myStrcat(char* destination, const char* source) {

    while (*destination != '\0') {
        destination++;
    }

    while (*source != '\0') {
        *destination = *source;  
        destination++;           
        source++;                
    }

    *destination = '\0';  
}

void myStrcpy(char* destination, const char* source) {

    while (*source != '\0') {
        *destination = *source;  
        destination++;           
        source++;                
    }
    *destination = '\0';  
}

const char* formatCurrentTimeToHour(time_t currentTime) {
    static char buffer[30];

    // Calculate time components manually
    int totalSeconds = currentTime % 86400;  // Seconds since midnight

    int hour = totalSeconds / 3600;
    int minute = (totalSeconds % 3600) / 60;
    int second = totalSeconds % 60;

    // Format time manually
    int i = 0;

    // Convert hour, minute, second to characters
    buffer[i++] = (hour / 10) + '0';
    buffer[i++] = (hour % 10) + '0';
    buffer[i++] = '_';

    buffer[i++] = (minute / 10) + '0';
    buffer[i++] = (minute % 10) + '0';
    buffer[i++] = '_';

    buffer[i++] = (second / 10) + '0';
    buffer[i++] = (second % 10) + '0';
    buffer[i] = '\0';  // Null-terminate the string

    return buffer;
}
const char* formatCurrentTimeToYear(time_t currentTime) {
    static char buffer[30];

    // Constants for time calculations
    const int SECONDS_IN_A_DAY = 86400;
    const int SECONDS_IN_A_YEAR = 31536000;
    const int SECONDS_IN_A_LEAP_YEAR = 31622400;
    const int DAYS_IN_MONTH[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    // Calculate year
    int year = 1970;
    int days = currentTime / SECONDS_IN_A_DAY;

    while (1) {
        int yearLength = ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) ? 366 : 365;
        if (days >= yearLength) {
            days -= yearLength;
            year++;
        } else {
            break;
        }
    }

    // Adjust for leap years in February
    int month = 0;
    int day = days;
    while (month < 12) {
        int daysInCurrentMonth = DAYS_IN_MONTH[month];
        if (month == 1 && ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))) {
            daysInCurrentMonth++;  // Leap year February adjustment
        }

        if (day >= daysInCurrentMonth) {
            day -= daysInCurrentMonth;
            month++;
        } else {
            break;
        }
    }

    // Format year, month, and day manually
    int i = 0;

    // Convert year to characters
    buffer[i++] = (year / 1000) + '0';
    buffer[i++] = ((year / 100) % 10) + '0';
    buffer[i++] = ((year / 10) % 10) + '0';
    buffer[i++] = (year % 10) + '0';
    buffer[i++] = '_';

    // Convert day (1-based index) to characters
    buffer[i++] = ((day + 1) / 10) + '0';
    buffer[i++] = ((day + 1) % 10) + '0';
    buffer[i++] = '_';
    
    // Convert month (1-based index) to characters
    buffer[i++] = ((month + 1) / 10) + '0';
    buffer[i++] = ((month + 1) % 10) + '0';


    buffer[i] = '\0';  // Null-terminate the string

    return buffer;
}

unsigned long long hashText(char textToHash[]) {

    unsigned long long hash = 5381; 
    int c;

    for (int i=0;textToHash[i]!='\0';i++){
        c=textToHash[i];
        hash = (hash * 33) + c; 
    }

    return hash;
}

int getLastId(char filePath[50], char delimiter) {
    char currentID[5]; 
    int lastID = -1; 

    fstream fileHandle(filePath, ios::in);

    while (fileHandle.getline(currentID, 5, delimiter)) {
        lastID = atoi(currentID);  
    }

    fileHandle.close();
    return lastID;
}

int getLength(const char array1[]){
    int total_length = 0;
    for (int i=0; array1[i]!='\0'; i++) {
        total_length++;
    }
    return total_length;
}

bool areEqual(const char array1[], const char array2[]) {
    if (getLength(array1)==getLength(array2)){
        for (int i=0;array1[i]!='\0';i++){
            if(array1[i]!=array2[i]){
                return false;
            }
        }
        return true;
    }

    return false;
}

bool myFind(char element_to_find, char arr_to_find_in[]) {
    for (int i = 0; arr_to_find_in[i] != '\0'; i++) { 
        if (arr_to_find_in[i] == element_to_find) {
            return true; 
        }
    }
    return false;
}

bool usernameAlreadyExists(const char username_to_check[],const char filepath[]){
    fstream userFileHandle(filepath,ios::in);
    char read_username[30];
    char read_pass[30];
    while (userFileHandle >> read_username >> read_pass){
        if (areEqual(read_username,username_to_check)){
            userFileHandle.close();
            return true;
        }
    }
    userFileHandle.close();
    return false;
}

void browseProductsSortedByAvailibilty() {
    ifstream productFileHandle;
    productFileHandle.open("products.txt"); 

    char buffer[100];
    int total_no_of_products = 0;

    while (productFileHandle.getline(buffer, 100, '\n')) {
        total_no_of_products++;
    }

    cout << GREEN << "[+] Total number of products: " << total_no_of_products << RESET << endl;
    productFileHandle.close();
    productFileHandle.open("products.txt");

    int* ids = new int[total_no_of_products];
    char** names = new char*[total_no_of_products];
    int* prices = new int[total_no_of_products];
    int* quantities = new int[total_no_of_products];
    char** categories = new char*[total_no_of_products];

    for (int i = 0; i < total_no_of_products; i++) {
        names[i] = new char[30];
        categories[i] = new char[30];
        productFileHandle >> ids[i] >> names[i] >> prices[i] >> quantities[i] >> categories[i];
    }

    for (int i = 0; i < total_no_of_products - 1; i++) {
        for (int j = 0; j < total_no_of_products - i - 1; j++) {
            if (quantities[j] > quantities[j + 1]) {

                swap(ids[j], ids[j + 1]);
                swap(prices[j], prices[j + 1]);
                swap(quantities[j], quantities[j + 1]);

                char tempName[30], tempCategory[30];
                myStrcpy(tempName, names[j]);
                myStrcpy(names[j], names[j + 1]);
                myStrcpy(names[j + 1], tempName);

                myStrcpy(tempCategory, categories[j]);
                myStrcpy(categories[j], categories[j + 1]);
                myStrcpy(categories[j + 1], tempCategory);
            }
        }
    }
    cout << left << setw(5) << "ID";
    cout << left << setw(30) << "Name";
    cout << left << setw(10) << "Price";
    cout << left << setw(10) << "Quantity";
    cout << "Category" << endl;

    for (int i = 0; i < total_no_of_products; i++) {
        cout << left << setw(5) << ids[i];
        cout << left << setw(30) << names[i];
        cout << left << setw(10) << prices[i];
        cout << left << setw(10) << quantities[i];
        cout << categories[i] << endl;
    }

    for (int i = 0; i < total_no_of_products; i++) {
        delete[] names[i];
        delete[] categories[i];
    }
    delete[] names;
    delete[] categories;
    delete[] ids;
    delete[] prices;
    delete[] quantities;

    productFileHandle.close();
}

void inventoryManagement(){
    cout << "What do you want to do?" << endl;
    cout << "1) Add new product" << endl;
    cout << "2) Delete a product" << endl;
    cout << "3) Edit a product" << endl;

    int inventoryChoice;
    cout << YELLOW << "[?] Enter a choice[1-3]: " << RESET;
    cin >> inventoryChoice;
    if (inventoryChoice == 1){
        char name[30];
        int price;
        int quantity;
        char category[30];
        char productFilePath[15] = {"products.txt"};
        int productID = getLastId(productFilePath,' ');

        if (cin.peek() == '\n') {
            cin.ignore();
        }
        cout << YELLOW << "[?] Enter product name: " << RESET;
        cin.getline(name, 30);
        cout << YELLOW << "[?] Enter product price: " << RESET;
        cin >> price;
        cout << YELLOW << "[?] Enter product quantity: " << RESET;
        cin >> quantity;
        cout << YELLOW << "[?] Choose product category: " << RESET;
        char output_category[30];
        int total_categories_counter = 0;
        int selected_category_choice;
        char selected_category_name[30];

        fstream categoriesFileHandle("categories.txt",ios::in);

        while(categoriesFileHandle>>output_category){
            total_categories_counter++;
            cout << total_categories_counter << ") ";
            cout << output_category << endl;
        }

        cout << YELLOW << "[?] Enter category choice[1-5]: " << RESET;
        cin >> selected_category_choice;
        if (selected_category_choice == 1) {
            myStrcpy(selected_category_name, "Furniture");
        } else if (selected_category_choice == 2) {
            myStrcpy(selected_category_name, "Fashion");
        } else if (selected_category_choice == 3) {
            myStrcpy(selected_category_name, "Household");
        } else if (selected_category_choice == 4) {
            myStrcpy(selected_category_name, "Food");
        } else if (selected_category_choice == 5) {
            myStrcpy(selected_category_name, "Electronics");
        } else {
            cout << RED << "[-] Invalid choice. Please select a valid category." << RESET << endl;
            return;
}
    fstream productsFileHandle("products.txt",ios::app);
    productsFileHandle << productID << " " << name << " " << price << " " << quantity << " " << category;
    productsFileHandle.close();
    categoriesFileHandle.close();

    }
    else if (inventoryChoice == 2){
        int input_productID;
        cout << YELLOW << "[?] Enter productID of item you want to remove: " << RESET;
        cin >> input_productID;

        fstream productFileHandle("products.txt",ios::in);
        fstream tempFileHandle("products_temp.txt",ios::app);

        int id;
        char name[30];
        int price;
        int quantity;
        char category[30];

        if (productFileHandle.is_open()){

            while(productFileHandle>>id>>name>>price>>quantity>>category){
            if (input_productID == id){
                    continue;
            }
            tempFileHandle << id  << " "<< name << " " << price << " "<< quantity << " " << category << endl; 

            }

        }

        productFileHandle.close();
        tempFileHandle.close();
        remove("products.txt");
        rename("products_temp.txt", "products.txt");
        cout << GREEN << "[+] Thie item has been successfully removed" << RESET << endl;
    }

    else if(inventoryChoice == 3){
        int input_productID;
        cout << YELLOW << "[?] Enter productID of item you want to update: " << RESET;
        cin >> input_productID;

        int id;
        char name[30];
        int price;
        int quantity;
        char category[30];

        fstream productFileHandle("products.txt",ios::in);
        if (productFileHandle.is_open()){
            cout << left << setw(5) << "ID";
            cout << left << setw(30) << "Name";
            cout << left << setw(10) << "Price";
            cout << left << setw(10) << "Quantity";
            cout << "Category" << endl;
            while(productFileHandle>>id>>name>>price>>quantity>>category){
                if (input_productID == id){
                    cout << left << setw(5) << id;
                    cout << left << setw(30) << name;
                    cout << left << setw(10) << price;
                    cout << left << setw(10) << quantity;
                    cout << category << endl;
                }

            }
            productFileHandle.close();
        }
        int col_choice;
        cout << "Which column do you want to update?" << endl;
        cout << "1) Name" << endl;
        cout << "2) Price" << endl;
        cout << "3) Quantity" << endl;

        cout << YELLOW << "[?] Enter a choice[1-3]: " << RESET;
        cin >> col_choice;
        if (col_choice == 1){
            char new_name[50];
            cout << "Enter new name: ";
            cin.ignore();
            cin.getline(new_name, 50);
            fstream productFileHandle("products.txt",ios::in);
            fstream tempFileHandle("products_temp.txt",ios::app);

            int id;
            char name[30];
            int price;
            int quantity;
            char category[30];

            if (productFileHandle.is_open()){

                while(productFileHandle>>id>>name>>price>>quantity>>category){
                if (input_productID == id){
                        tempFileHandle << id << " " << new_name << " " << price << " "<< quantity << " " << category << endl; 
                        continue;
                }
                tempFileHandle << id << " " << name << " " << price << " "<< quantity << " " << category << endl; 

                }

            }

            productFileHandle.close();
            tempFileHandle.close();
            remove("products.txt");
            rename("products_temp.txt", "products.txt");
            cout << GREEN << "[+] Thie item has been successfully updated" << RESET << endl;

        }else if (col_choice == 2){
            char new_price[50];
            cout << YELLOW << "[?] Enter new price: " << RESET;
            cin.ignore();
            cin.getline(new_price, 50);
            fstream productFileHandle("products.txt",ios::in);
            fstream tempFileHandle("products_temp.txt",ios::app);

            int id;
            char name[30];
            int price;
            int quantity;
            char category[30];

            if (productFileHandle.is_open()){

                while(productFileHandle>>id>>name>>price>>quantity>>category){
                if (input_productID == id){
                        tempFileHandle << id << " " << name << " " << new_price << " "<< quantity << " " << category << endl; 
                    continue;
                }
                tempFileHandle << id << " " << name << " " << price << " "<< quantity << " " << category << endl; 

                }

            }

            productFileHandle.close();
            tempFileHandle.close();
            remove("products.txt");
            rename("products_temp.txt", "products.txt");
            cout << GREEN << "[+] Thie item has been successfully updated" << RESET << endl;
        }else if (col_choice == 3){
             char new_quantity[50];
            cout << YELLOW << "[?] Enter new quantity: " << RESET;
            cin.ignore();
            cin.getline(new_quantity, 50);
            fstream productFileHandle("products.txt",ios::in);
            fstream tempFileHandle("products_temp.txt",ios::app);

            int id;
            char name[30];
            int price;
            int quantity;
            char category[30];

            if (productFileHandle.is_open()){

                while(productFileHandle>>id>>name>>price>>quantity>>category){
                if (input_productID == id){
                        tempFileHandle << id << " " << name << " " << price << " "<< new_quantity << " " << category << endl; 
                        continue;
                }
                tempFileHandle << id << " " << name << " " << price << " "<< quantity << " " << category << endl; 

                }

            }

            productFileHandle.close();
            tempFileHandle.close();
            remove("products.txt");
            rename("products_temp.txt", "products.txt");
            cout << GREEN << "[+] Thie item has been successfully updated" << RESET << endl; 
        }

    }

}

bool productExists(int input_productID){
    int id;
    char name[30];
    int price;
    int quantity;
    char category[30];

    fstream productFileHandle("products.txt",ios::in);
    if (productFileHandle.is_open()){
        while(productFileHandle>>id>>name>>price>>quantity>>category){
            if (id==input_productID){
                productFileHandle.close();
                return true;
            }

        }
        productFileHandle.close();
        return false;
    }
    return false;

}