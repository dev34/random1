#ifndef HELPERFUNCTIONS_H
#define HELPERFUNCTIONS_H
#include "project.h"


void myStrcat(char* destination, const char* source);
 

void myStrcpy(char* destination, const char* source);



const char* formatCurrentTimeToHour(time_t currentTime);
const char* formatCurrentTimeToYear(time_t currentTime);

unsigned long long hashText(char textToHash[]) ;

int getLastId(char filePath[50], char delimiter);

int getLength(const char array1[]);


bool areEqual(const char array1[], const char array2[]);

bool myFind(char element_to_find, char arr_to_find_in[]);
bool usernameAlreadyExists(const char username_to_check[],const char filepath[]);

void browseProductsSortedByAvailibilty();

void inventoryManagement();

bool productExists(int input_productID);

#endif