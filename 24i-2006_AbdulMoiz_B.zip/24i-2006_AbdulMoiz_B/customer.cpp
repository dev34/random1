#include "customer.h"
using namespace std;



char global_username[30];



int userLogin(){
    char input_username[30];
    char input_password[30];

    cout << YELLOW << "[?] Enter username: " << RESET;
    cin.getline(input_username,30);
    if (getLength(input_username) > 30){
        cout << RED << "[-] Username must be less than 30 characters" << RESET << endl;
        return false;
    }
    if (myFind(' ',input_username)){
        cout << RED << "[-] Username cannot contain spaces" << RESET << endl;
        return false;
    }

    cout << YELLOW << "[?] Enter password: " << RESET;
    cin.getline(input_password,30);
    if (getLength(input_password) > 30){
        cout << RED << "[-] Password must be less than 30 characters" << RESET << endl;
        return false;
    }
    if (myFind(' ',input_password)){
        cout << RED << "[-] Password cannot contain spaces" << RESET << endl;
        return false;
    }

    fstream userFileHandle("users.txt",ios::in);
    char stored_username[30]; 
    char stored_password[30];
    if (userFileHandle.is_open()){
        while(userFileHandle>>stored_username>>stored_password){

            if (areEqual(stored_username, input_username) && (hashText(input_password) == stoull(stored_password))){
                myStrcpy(global_username, stored_username);
                cout << GREEN << "[+] Login Successful" << endl << RESET;
                return true;
            }
        }
    }
    userFileHandle.close();
    fstream activityLogFileHandle("activityLogs.txt",ios::app);
    time_t currentTime = time(0);
    activityLogFileHandle << input_username << " " <<input_password << " " << currentTime << " 0" << endl;
    activityLogFileHandle.close();
    cout << RED << "[-] Login Failed" << endl << RESET;
    return false;
}




int userRegister(){
    char input_username[30];
    char input_password[30];
    char input_confirmed_password[30];

    cout << YELLOW << "[?] Enter username: " << RESET;
    cin.getline(input_username,30);
    if (getLength(input_username) > 30){
        cout << RED << "[-] Username must be less than 30 characters" << RESET << endl;
        return false;
    }
    if (myFind(' ',input_username)){
        cout << RED << "[-] Username cannot contain spaces" << RESET << endl;
        return false;
    }

    cout << YELLOW << "[?] Enter password: " << RESET;
    cin.getline(input_password,30);
    if (getLength(input_password) > 30){
        cout << RED << "[-] Password must be less than 30 characters" << RESET << endl;
        return false;
    }
    if (myFind(' ',input_password)){
        cout << RED << "[-] Password cannot contain spaces" << RESET << endl;
        return false;
    }

    cout << YELLOW << "[?] Confirm password: " << RESET;
    cin.getline(input_confirmed_password,30);

    if (!(areEqual(input_password, input_confirmed_password))){
        cout << RED << "[-] Passwords do not match" << RESET << endl;
        return false;
    }

    if(usernameAlreadyExists(input_username,"users.txt")){
        cout << RED << "[-] Username already exists" << RESET << endl;
        return false;
    }

    fstream userFileHandle("users.txt",ios::app);
    
    if (userFileHandle.is_open()){
        userFileHandle << input_username << " " << hashText(input_password) << endl;
    }
    
    userFileHandle.close();
    return true;
}



void browseProducts(){
    //id, name, price, quantity, category
    int id;
    char name[30];
    int price;
    int quantity;
    char category[30];

    fstream productFileHandle("products.txt",ios::in);
    if (productFileHandle.is_open()){
        cout << left << setw(5) << "ID";
        cout << left << setw(30) << "Name";
        cout << left << setw(10) << "Price";
        cout << left << setw(10) << "Quantity";
        cout << "Category" << endl;
        while(productFileHandle>>id>>name>>price>>quantity>>category){
            cout << left << setw(5) << id;
            cout << left << setw(30) << name;
            cout << left << setw(10) << price;
            cout << left << setw(10) << quantity;
            cout << category << endl;
        }
    }
    productFileHandle.close();
}

void browseProductsSortedByPrice() {
    ifstream productFileHandle;
    productFileHandle.open("products.txt"); 


    char buffer[100];
    int total_no_of_products = 0;

    while (productFileHandle.getline(buffer, 100, '\n')) {
        total_no_of_products++;
    }

    cout << endl << GREEN << "[+] Total number of products: " << total_no_of_products << RESET << endl;
    productFileHandle.close();
    productFileHandle.open("products.txt");
    
    // dma for product columns
    int* ids = new int[total_no_of_products];
    char** names = new char*[total_no_of_products];
    int* prices = new int[total_no_of_products];
    int* quantities = new int[total_no_of_products];
    char** categories = new char*[total_no_of_products];

    for (int i = 0; i < total_no_of_products; i++) {
        names[i] = new char[30];
        categories[i] = new char[30];
        productFileHandle >> ids[i] >> names[i] >> prices[i] >> quantities[i] >> categories[i];
    }

    //bubble sort
    for (int i = 0; i < total_no_of_products - 1; i++) {
        for (int j = 0; j < total_no_of_products - i - 1; j++) {
            if (prices[j] > prices[j + 1]) {

                swap(ids[j], ids[j + 1]);
                swap(prices[j], prices[j + 1]);
                swap(quantities[j], quantities[j + 1]);

                char tempName[30], tempCategory[30];
                myStrcpy(tempName, names[j]);
                myStrcpy(names[j], names[j + 1]);
                myStrcpy(names[j + 1], tempName);

                myStrcpy(tempCategory, categories[j]);
                myStrcpy(categories[j], categories[j + 1]);
                myStrcpy(categories[j + 1], tempCategory);
            }
        }
    }
    cout << left << setw(5) << "ID";
    cout << left << setw(30) << "Name";
    cout << left << setw(10) << "Price";
    cout << left << setw(10) << "Quantity";
    cout << "Category" << endl;

    for (int i = 0; i < total_no_of_products; i++) {
        cout << left << setw(5) << ids[i];
        cout << left << setw(30) << names[i];
        cout << left << setw(10) << prices[i];
        cout << left << setw(10) << quantities[i];
        cout << categories[i] << endl;
    }

 
    for (int i = 0; i < total_no_of_products; i++) {
        delete[] names[i];
        delete[] categories[i];
    }
    delete[] names;
    delete[] categories;
    delete[] ids;
    delete[] prices;
    delete[] quantities;

    productFileHandle.close();
}


void searchProduct(){
    int filter_choice;
    cout << "Filter by: " << endl;
    cout << "1) Name" << endl;
    cout << "2) Category" << endl;
    cout << "3) Price" << endl;
    cout << "4) Availability" << endl;
    cout << YELLOW << "[?] Enter choice[1-4]: " << RESET;
    cin >> filter_choice;
    cin.ignore();

    fstream productFileHandle("products.txt",ios::in);

    if (filter_choice==1){
        char input_name[30];

        cout << YELLOW << "[?] Product name: " << RESET;
        cin.getline(input_name,30);

        int id;
        char name[30];
        int price;
        int quantity;
        char category[30];

        if (productFileHandle.is_open()){
            cout << left << setw(5) << "ID";
            cout << left << setw(30) << "Name";
            cout << left << setw(10) << "Price";
            cout << left << setw(10) << "Quantity";
            cout << "Category" << endl;
            while(productFileHandle>>id>>name>>price>>quantity>>category){
                if (areEqual(input_name, name)){
                    cout << left << setw(5) << id;
                    cout << left << setw(30) << name;
                    cout << left << setw(10) << price;
                    cout << left << setw(10) << quantity;
                    cout << category << endl;
                }

            }
        }
        productFileHandle.close();

    }
    else if (filter_choice == 2){
        char output_category[30];
        int total_categories_counter = 0;
        int selected_category_choice;
        char selected_category_name[30];
        
        int id;
        char name[30];
        int price;
        int quantity;
        char category[30];

        fstream categoriesFileHandle("categories.txt",ios::in);
        cout << "Available Categories:" << endl;
        while(categoriesFileHandle>>output_category){
            total_categories_counter++;
            cout << total_categories_counter << ") ";
            cout << output_category << endl;
        }

        cout << YELLOW << "[?] Enter category choice[1-5]: " << RESET;
        cin >> selected_category_choice;
        if (selected_category_choice == 1) {
            myStrcpy(selected_category_name, "Furniture");
        } else if (selected_category_choice == 2) {
            myStrcpy(selected_category_name, "Fashion");
        } else if (selected_category_choice == 3) {
            myStrcpy(selected_category_name, "Household");
        } else if (selected_category_choice == 4) {
            myStrcpy(selected_category_name, "Food");
        } else if (selected_category_choice == 5) {
            myStrcpy(selected_category_name, "Electronics");
        } else {
            cout << "Invalid choice. Please select a valid category." << endl;
            return;
}

        if (productFileHandle.is_open()){
            cout << left << setw(5) << "ID";
            cout << left << setw(30) << "Name";
            cout << left << setw(10) << "Price";
            cout << left << setw(10) << "Quantity";
            cout << "Category" << endl;
            while(productFileHandle>>id>>name>>price>>quantity>>category){
                if (areEqual(selected_category_name, category)){
                    cout << left << setw(5) << id;
                    cout << left << setw(30) << name;
                    cout << left << setw(10) << price;
                    cout << left << setw(10) << quantity;
                    cout << category << endl;
                }

            }
        }
        categoriesFileHandle.close();
        productFileHandle.close();
        
    }else if (filter_choice == 3){
        browseProductsSortedByPrice();

    }else if (filter_choice == 4){
        browseProductsSortedByAvailibilty();
    }
    else {
        cout << RED << "[-] Invalid choice" << RESET << endl;
        productFileHandle.close();
        return;
    }
}

void addToCart(){
    fstream productFileHandle("products.txt",ios::in);
    int input_productID;
    int input_quantity;
    char filePath[50];
    //filepath is: cart/username_cart.txt
    myStrcpy(filePath, "cart/"); // store in cart folder
    myStrcat(filePath, global_username); // append username
    myStrcat(filePath, "_cart.txt");

    fstream cartFileHandle(filePath,ios::app);
    cout << YELLOW << "[?] Enter product ID: " << RESET;
    cin >> input_productID;
    cout << YELLOW << "[?] Quantity? " << RESET;
    cin >> input_quantity;
    cin.ignore();

    int id;
    char name[30];
    int price;
    int quantity;
    char category[30];

    

    if (productFileHandle.is_open()){

        while(productFileHandle>>id>>name>>price>>quantity>>category){
            if (input_productID == id){
                if (quantity == 0){
                    cout << RED << "[-] The product is out of stock ): try later" << RESET << endl;
                    break;
                }
                if (input_quantity> quantity){
                    cout << RED << "[-] The stock dosen't have enough items" << RESET << endl;
                    break;
                }
                cartFileHandle << id << " " << name << " " << (price) << " " << input_quantity << " " << category << endl;
                cout << GREEN << "[+] The product has been added to your cart" << RESET << endl;
                break;
            }
        
        }
        
    }
    
    productFileHandle.close();
    
    cartFileHandle.close();
}

int viewCart(){
    char filePath[50];
    myStrcpy(filePath, "cart/"); // store in cart folder
    myStrcat(filePath, global_username); // append username
    myStrcat(filePath, "_cart.txt"); 
    fstream cartFileHandle(filePath,ios::in);


    int id;
    char name[30];
    int price;
    int quantity;
    int total_price = 0;
    char category[30];

    

    if (cartFileHandle.is_open()){
        cout << "------------------------------------------------------------------"<<endl;
        cout << left << setw(5) << "ID";
        cout << left << setw(30) << "Name";
        cout << left << setw(10) << "Price";
        cout << left << setw(10) << "Quantity";
        cout << "Category" << endl;
        while(cartFileHandle>>id>>name>>price>>quantity>>category){
           
            cout << left << setw(5) << id;
            cout << left << setw(30) << name;
            cout << left << setw(10) << price;
            cout << left << setw(10) << quantity;
            cout << category << endl;
            
            total_price += (price*quantity);
            
            
        
        }
        cout << "------------------------------------------------------------------"<<endl;
        cout << GREEN << "[+] Total Price: " << total_price << RESET << endl;
        
    }
    
    cartFileHandle.close();
    return total_price;
}

void removeFromCart(){
    int input_productID;
    cout << YELLOW << "[?] Enter productID of item you want to remove: " << RESET;
    cin >> input_productID;
    cin.ignore();

    char filePath[50];
    myStrcpy(filePath, "cart/"); // store in cart folder
    myStrcat(filePath, global_username); // append username
    myStrcat(filePath, "_cart.txt"); 

    fstream cartFileHandle(filePath,ios::in);
    fstream tempFileHandle("cart/cart_temp.txt",ios::out);

    int id;
    char name[30];
    int price;
    int quantity;
    char category[30];

    

    if (cartFileHandle.is_open()){
        
        
        while(cartFileHandle>>id>>name>>price>>quantity>>category){
           if (input_productID == id){
                continue;
           }
           tempFileHandle << id << " " << name << " " << price << " " << quantity << " " << category << endl; 
            

        
        
        }
        
    }
   
    
    cartFileHandle.close();
    tempFileHandle.close();
    remove(filePath);
    rename("cart/cart_temp.txt", filePath);
    cout << GREEN << "[+] This item has been successfully removed" << RESET << endl;
}

//start_wishlist
void addToWishlist(){
    fstream productFileHandle("products.txt",ios::in);
    int input_productID;
    char filePath[50];
    myStrcpy(filePath, "wishlist/");
    myStrcat(filePath, global_username);
    myStrcat(filePath, "_wishlist.txt"); 
    fstream wishlistFileHandle(filePath,ios::app);
    cout << YELLOW << "[?] Enter product ID: " << RESET;
    cin >> input_productID;
    cin.ignore();

    int id;
    char name[30];
    int price;
    int quantity;
    char category[30];

    

    if (productFileHandle.is_open()){

        while(productFileHandle>>id>>name>>price>>quantity>>category){
            if (input_productID == id){
                wishlistFileHandle << id << " " << name << " " << price << " " << quantity << " " << category << endl;
                cout << GREEN << "[+] The product has been added to your wishlist" << RESET << endl;
                break;
            }
        
        }
        
    }
    
    productFileHandle.close();
    
    wishlistFileHandle.close();
}

void viewWishlist(){
    char filePath[50];
    myStrcpy(filePath, "wishlist/"); // store in cart folder
    myStrcat(filePath, global_username); // append username
    myStrcat(filePath, "_wishlist.txt"); 
    fstream wishlistFileHandle(filePath,ios::in);


    int id;
    char name[30];
    int price;
    int quantity;
    char category[30];

    

    if (wishlistFileHandle .is_open()){
        cout << "------------------------------------------------------------------"<<endl;
        cout << left << setw(5) << "ID";
        cout << left << setw(30) << "Name";
        cout << left << setw(10) << "Price";
        cout << left << setw(10) << "Quantity";
        cout << "Category" << endl;
        while(wishlistFileHandle>>id>>name>>price>>quantity>>category){
           
            cout << left << setw(5) << id;
            cout << left << setw(30) << name;
            cout << left << setw(10) << price;
            cout << left << setw(10) << quantity;
            cout << category << endl;
        
        }
        cout << "------------------------------------------------------------------"<<endl;
        
    }
    
    wishlistFileHandle.close();
}

void removeFromWishlist(){
    int input_productID;
    cout << YELLOW << "[?] Enter productID of item you want to remove: " << RESET;
    cin >> input_productID;
    cin.ignore();

    char filePath[50];
    myStrcpy(filePath, "wishlist/"); // store in cart folder
    myStrcat(filePath, global_username); // append username
    myStrcat(filePath, "_wishlist.txt"); 

    fstream wishlistFileHandle(filePath,ios::in);
    fstream tempFileHandle("wishlist/wishlist_temp.txt",ios::out);

    int id;
    char name[30];
    int price;
    int quantity;
    char category[30];

    

    if (wishlistFileHandle.is_open()){
        
        
        while(wishlistFileHandle>>id>>name>>price>>quantity>>category){
           if (input_productID == id){
                continue;
           }
           tempFileHandle << id << " " << name << " " << price << " " << quantity << " " << category << endl; 
            

        
        
        }
        
    }
   
    
    wishlistFileHandle.close();
    tempFileHandle.close();
    remove(filePath);
    rename("wishlist/wishlist_temp.txt", filePath);
    cout << GREEN << "[+] This item has been successfully removed" << RESET << endl;
}
// end wishlist

void checkout() {
    int total_price = viewCart();
    int total_discounted_price = 0;
    if (total_price <= 0) {
        cout << RED << "[-] Cart must not be empty...returning" << RESET << endl;
        return;
    }

    char is_final;
    cout << YELLOW << "[?] Is everything final (y/n)? " << RESET;
    cin >> is_final;
    cin.ignore();
    if (is_final == 'n' || is_final == 'N') {
        cout << RED << "[-] Exiting...you can update the cart and checkout later" << RESET << endl;
        return;
    } else if (is_final == 'y' || is_final == 'Y') {
        char isEnterCode;
        cout << YELLOW << "[?] Do you want to enter a promo code (Y/n)? " << RESET;
        cin >> isEnterCode;
        cin.ignore();

        // setting the discount percentage to 0 firstly
        int discountPercentage = 0;
        int eligibleProducts[30];  // eligible product IDs
        int eligibleProductCount = 0; // no. of eligible products
        bool discountApplied = false; // check if discount is applied

        if (isEnterCode == 'y' || isEnterCode == 'Y') {
            char discount_code[50];
            cout << YELLOW << "[?] DISCOUNT CODE: " << RESET;
            cin.getline(discount_code, 50);

            // Step 1: Check the discount percentage and eligible product IDs from discount_codes.txt
            fstream discountFile("discount_codes.txt", ios::in);
            if (!discountFile.is_open()) {
                cout << RED << "[-] Failed to open discount codes file" << RESET << endl;
                return;
            }

            char code[30];
            char productIds[100];
            int fileDiscount;

            bool codeFound = false;
            while (discountFile >> code >> productIds >> fileDiscount) {
               if (areEqual(code, discount_code)) {
                    codeFound = true;

                    // parse product IDs using dynamic memory allocation
                    int length = getLength(productIds);
                    char* tempProductIds = new char[length + 1];
                    myStrcpy(tempProductIds, productIds);

                    int start = 0;
                    for (int i = 0; i <= length; i++) {
                        if (tempProductIds[i] == ',' || tempProductIds[i] == '\0') {
                            tempProductIds[i] = '\0';  // end the current one so that atoi can process it
                            eligibleProducts[eligibleProductCount++] = atoi(tempProductIds + start);
                            start = i + 1;  // update start to the next id start
                        }
                    }

                    delete[] tempProductIds;

                    // Step 2: Update the discount percentage
                    discountPercentage = fileDiscount;
                    break;

                }
            }

            discountFile.close();

            if (!codeFound) {
                cout << RED << "[-] Invalid discount code" << RESET << endl;
            }
        }

        // Step 1: Copy cart to order file
        char cartFilePath[50];
        char orderFilePath[50];
        int currentTime = time(0);
        myStrcpy(orderFilePath, "orders/");
        myStrcat(orderFilePath,formatCurrentTimeToYear(currentTime));
        myStrcat(orderFilePath, "/");
        if (!(filesystem::exists(orderFilePath))){
            filesystem::create_directories(orderFilePath);
        }
        myStrcat(orderFilePath, global_username);
        myStrcat(orderFilePath, "_order.txt");

        

        myStrcpy(cartFilePath, "cart/");
        myStrcat(cartFilePath, global_username);
        myStrcat(cartFilePath, "_cart.txt");

        fstream orderFileHandle(orderFilePath, ios::app);
        fstream cartFileHandle(cartFilePath, ios::in);

        if (!orderFileHandle.is_open() || !cartFileHandle.is_open()) {
            cout << "Error opening cart or order files!" << endl;
            return;
        }

        int id;
        char name[30];
        int price;
        int bought_quantity;
        char category[30];

while (cartFileHandle >> id >> name >> price >> bought_quantity >> category) {
    int originalPrice = price * bought_quantity;

    // Check if the product ID is eligible for discount
    bool isEligibleForDiscount = false;
    for (int i = 0; i < eligibleProductCount; i++) {
        if (eligibleProducts[i] == id) {
            isEligibleForDiscount = true;
            break;
        }
    }

    // If eligible apply discount
    if (isEligibleForDiscount) {
        int discountAmount = (originalPrice * discountPercentage) / 100;
        int discountedPrice = originalPrice - discountAmount;
        total_discounted_price += discountedPrice;  // Accumulate the discounted price

        // Write the product to the order file with discount
        orderFileHandle << id << " " << name << " " << discountedPrice / bought_quantity << " " 
                        << bought_quantity << " " << category << endl;

        discountApplied = true;  // Mark that a discount has been applied
    } else {
        // If not eligible for discount, write original price
        total_discounted_price += originalPrice;  
        orderFileHandle << id << " " << name << " " << price << " " 
                        << bought_quantity << " " << category << endl;
    }
}

        cartFileHandle.close();
        orderFileHandle.close();

        // Step 2: Update products file
        char productsFilePath[] = "products.txt";
        char tempFilePath[] = "temp_products.txt";

        ifstream productsFile(productsFilePath);
        ofstream tempFile(tempFilePath);

        cartFileHandle.open(cartFilePath, ios::in);

        // Array index is id, and value is quantity
        int cartQuantities[100] = {0};  

        while (cartFileHandle >> id >> name >> price >> bought_quantity >> category) {
            cartQuantities[id] = bought_quantity;
        }

        cartFileHandle.close();

        int productID;
        int productPrice;
        int productQuantity;
        char productName[30];
        char productCategory[30];

        while (productsFile >> productID >> productName >> productPrice >> productQuantity >> productCategory) {
            if (cartQuantities[productID] > 0) {
                productQuantity -= cartQuantities[productID];
            }
            tempFile << productID << " " << productName << " " << productPrice << " "
                     << productQuantity << " " << productCategory << endl;
        }

        productsFile.close();
        tempFile.close();

        remove(productsFilePath);
        rename(tempFilePath, productsFilePath);
        remove(cartFilePath); // clear cart
        // Output the final message only if a discount was applied
        cout << "==================================" << endl;
cout << "Original Total Price: " << total_price << endl;
if (discountApplied) {
    cout << "Discounted Total Price: " << total_discounted_price << endl;
    cout << GREEN << "[+] You saved: " << total_price - total_discounted_price << RESET << endl;
} else {
    cout << RED << "[-] No discounts applied. Final Price: " << total_discounted_price << RESET << endl;
}
cout << "==================================" << endl;
cout << GREEN << "[+] Order has been successfully placed!" << RESET << endl;
    } else {
        cout << RED << "[-] Invalid choice...returning to home screen" << RESET << endl;
        return;
    }
}


int getLastId(const char* filePath, char delimiter) {
    char currentID[5]; 
    int lastID = -1; 

    fstream fileHandle(filePath, ios::in);

    while (fileHandle.getline(currentID, 5, delimiter)) {
        lastID = atoi(currentID);  //convert to integer
    }

    fileHandle.close();
    return lastID;
}

int getLastIdFromFeedback(const char* filename) {
    ifstream file(filename);
    if (!file) {
        cout << "Error opening file!" << endl;
        return -1;
    }
    
    char line[256];
    int lastID = -1;

    while (file.getline(line, sizeof(line))) {
        // Extract the portion before the '|'
        char idPart[256];
        int i = 0;

        while (line[i] != '|' && line[i] != '\0') {
            idPart[i] = line[i];  // Copy characters
            i++;
        }
        idPart[i] = '\0'; 

        lastID = atoi(idPart);  
    }

    file.close();
    return lastID;
}

bool productExistsInOrderFile(int input_productID) {
    // base directory for orders
    const char* baseFolder = "orders";

    // iterate through all subdirectories in the orders folder
    for (const auto& entry : filesystem::directory_iterator(baseFolder)) {
        if (entry.is_directory()) {
            // construct the file path for <global_username>_order.txt in the current subdirectory
            string orderFilePath = string(entry.path().string()) + "/" + global_username + "_order.txt";

            // Open the order file
            fstream orderFileHandle(orderFilePath, ios::in);
            if (orderFileHandle.is_open()) {
                int id;
                char name[30];
                int price;
                int quantity;
                char category[30];

                // Read through the order file and search for the product ID
                while (orderFileHandle >> id >> name >> price >> quantity >> category) {
                    if (id == input_productID) {
                        orderFileHandle.close();
                        return true;  // Product found
                    }
                }
                orderFileHandle.close();
            }
        }
    }

    return false;  // Product not found in any order file
}









void makeSupportRequest(){

    char supportQuestion[500];
    cout << "Enter your inquiry: ";
    cin.getline(supportQuestion, 500, '\n');
    if (!myFind('|',supportQuestion)){  // bcz we are using | as separator
        fstream supportFileHandle("support.txt",ios::app);
        int last_id=getLastIdFromFeedback("support.txt");
        supportFileHandle << (last_id+1) << "|" << global_username << "|" << supportQuestion << "|" << "0" << "|" << endl; //0 = unresolved, 1 = resolved
        cout << GREEN << "[+] Your inquiry has been recorded" << RESET << endl;
        supportFileHandle.close();
    }
    else{
        cout << "Message cannot contain |" << endl;
    }
}

void viewPastSupportRequests() {
    char supportID[5];
    char supportUsername[30];
    char supportQuestion[500];
    char supportStatus[2];
    char employeeName[30];
    char supportResponse[500];



    fstream supportFileHandle("support.txt", ios::in);


    while (supportFileHandle.getline(supportID, 30, '|')) {
        supportFileHandle.getline(supportUsername, 30, '|');
        supportFileHandle.getline(supportQuestion, 500, '|');
        supportFileHandle.getline(supportStatus, 2, '|');  // read '0' or '1'
        if (areEqual(supportStatus, "1")) {
            supportFileHandle.getline(employeeName, 30, '|'); 
        }
        
        supportFileHandle.getline(supportResponse, 500); 
        if (areEqual(supportUsername,global_username)){
            if (areEqual(supportStatus, "0")) {
                cout << RED;
                cout << "Inquiry: " << supportQuestion << endl;
                cout << "Status: Unresolved" << endl;
            } else if (areEqual(supportStatus, "1")) {
                cout << GREEN;
                cout << "Inquiry: " << supportQuestion << endl;
                cout << "Status: Resolved (by " << employeeName << ")" << endl;
                cout << "Response: " << supportResponse << endl;
            } else {
                cout << YELLOW;

                cout << "Inquiry: " << supportQuestion << endl;
                cout << "Status: (unknown status)" << endl;
            }
            cout << endl;
        }
        
    }

    cout << RESET;
    supportFileHandle.close();
}

void getNotifications(){
    bool isFirst=true;
    fstream notificationFileHandle("notifications.txt",ios::in);
    char read_username[30];
    char read_msg[500];
    while (notificationFileHandle.getline(read_username, 30, '|')){
        notificationFileHandle.getline(read_msg, 500);

        if (areEqual(read_username, global_username)){
            if(isFirst){
                cout << "[+] Announcements: " << endl;
                isFirst=false;
            }
            cout << read_msg << endl;
        }

    }
    notificationFileHandle.close();
}

void getOrderHistoryAndProvideFeedback() {
    // Define the base orders directory
    const char* baseFolder = "orders";

    // List subdirectories (dates) in the orders directory
    int folderCount = 0;
    char** folderPaths = nullptr;

    for (const auto& entry : filesystem::directory_iterator(baseFolder)) {
        if (entry.is_directory()) {
            // Expand the folder paths array
            char** newFolderPaths = new char*[folderCount + 1];
            for (int i = 0; i < folderCount; i++) {
                newFolderPaths[i] = folderPaths[i];
            }
            delete[] folderPaths;
            folderPaths = newFolderPaths;

            folderPaths[folderCount] = new char[100];
            myStrcpy(folderPaths[folderCount], entry.path().string().c_str());
            cout << folderCount + 1 << ". " << entry.path().filename().string() << "\n";
            folderCount++;
        }
    }

    if (folderCount == 0) {
        cout << "[-] No order subdirectories found.\n";
        return;
    }

    int choice;
    cout << YELLOW << "[?] Enter your choice (1-" << folderCount << "): " << RESET;
    cin >> choice;

    if (choice < 1 || choice > folderCount) {
        cout << "[-] Invalid choice. Exiting...\n";
        for (int i = 0; i < folderCount; i++) {
            delete[] folderPaths[i];
        }
        delete[] folderPaths;
        return;
    }

    // Construct the path to the selected folder
    const char* selectedFolder = folderPaths[choice - 1];
    string orderFilePath = string(selectedFolder) + "/" + global_username + "_order.txt";

    // Open the cart file
    fstream orderFileHandle(orderFilePath, ios::in);
    if (orderFileHandle.is_open()) {
        int id, price, quantity;
        char name[30], category[30];

        cout << left << setw(5) << "ID";
        cout << left << setw(30) << "Name";
        cout << left << setw(10) << "Price";
        cout << left << setw(10) << "Quantity";
        cout << "Category" << endl;

        // Read and display the contents of the cart file
        while (orderFileHandle >> id >> name >> price >> quantity >> category) {
            cout << left << setw(5) << id;
            cout << left << setw(30) << name;
            cout << left << setw(10) << price;
            cout << left << setw(10) << quantity;
            cout << category << endl;
        }

        orderFileHandle.close();
    } else {
        cout << "[-] Unable to open the order file for " << global_username << endl;
        return;
    }

    char isGiveFeedback;
    cout << YELLOW << "[?] Do you want to give feedback on a product (Y/n)? " << RESET;
    cin >> isGiveFeedback;
    if (isGiveFeedback == 'Y' || isGiveFeedback == 'y'){
        int productID;
        cout << YELLOW << "[?] Enter product ID: " << RESET;
        cin >> productID;
        cin.ignore();
        if (productExistsInOrderFile(productID)){

            char feedbackQuestion[500]; //feedbackID|customer_username|productID|feedbackQuestion|status|employee_name|feedbackAnswer
            cout << YELLOW << "[?] Enter feedback: " << RESET;
            cin.getline(feedbackQuestion, 500, '\n');
            if (!myFind('|',feedbackQuestion)){
            
                fstream feedbackFileHandle("feedback.txt", ios::app);
                int last_id=getLastIdFromFeedback("feedback.txt");
                feedbackFileHandle << (last_id+1) << "|" << global_username << "|" << productID <<  "|" << feedbackQuestion << "|" << "0" << "|" << endl; //0 = unresponed, 1 = responded
                cout << GREEN << "[+] Feedback has been recorded" << endl;
                cout << RESET;
                feedbackFileHandle.close();
            }
            else{
                cout << "Message caannot contain |" << endl;

            }

        }
        else{
            cout << RED << "[-] You can only give feedback on items u have previously purchased" << RESET << endl;
            orderFileHandle.close();

        }
    }

    for (int i = 0; i < folderCount; i++) {
        delete[] folderPaths[i];
    }
    delete[] folderPaths;
}