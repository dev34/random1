#ifndef CUSTOMER_H
#define CUSTOMER_H
#include "project.h"

int userLogin();
int userRegister();
void browseProducts();
void browseProductsSortedByPrice();
void searchProduct();
void addToCart();
int viewCart();
void removeFromCart();
void addToWishlist();
void viewWishlist();
void removeFromWishlist();
void checkout();
int getLastId(const char* filePath, char delimiter);
int getLastIdFromFeedback(const char* filename);
bool productExistsInOrderFile(int input_productID);
void getOrderHistoryAndProvideFeedback();
void makeSupportRequest();
void viewPastSupportRequests();
void getNotifications();


#endif