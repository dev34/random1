#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include "project.h"

int employeeLogin();
int employeeRegister();
int getLastId(char filePath[50], char delimiter);
void findProductById(char id[]);
bool idExistsInFeedback(char id[]);
bool idExistsInSupport(char id[]);
void incrementEmployeeScore(char employeeName[]);
void respondToSupportRequest();
void alertEmployee();
void respondToFeedback();
void getEmployeeContributions();
void sendNotification();


#endif