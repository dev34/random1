#include "project.h"
using namespace std;

int main() {

cout << CYAN <<" ____                             ____  _                 " << endl;
cout << CYAN <<"/ ___|  ___  ___ _   _ _ __ ___  / ___|| |__   ___  _ __  " << endl;
cout << CYAN <<"\\___ \\ / _ \\/ __| | | | '__/ _ \\ \\___ \\| '_ \\ / _ \\| '_ \\ " << endl;
cout << CYAN <<" ___) |  __/ (__| |_| | | |  __/  ___) | | | | (_) | |_) |" << endl;
cout << CYAN <<"|____/ \\___|\\___|\\__,_|_|  \\___| |____/|_| |_|\\___/| .__/ " << endl;
cout << CYAN <<"                                                   |_|    " << RESET <<endl;

userRoleMenu:
    char choice;
    cout << "1) User" << endl;
    cout << "2) Employee" << endl;
    cout << "3) Admin" << endl;
    cout << "==============================================" << endl;
    cout << YELLOW << "[?] Enter choice[1-3]: " << RESET;
    cin >> choice;
    cin.ignore();
    switch (choice){
        
            case '1':
            cout << endl;
            userRegisterLoginMenu:
                char subUserChoice;
                cout << endl;
                cout << "User Login" << endl;
                cout << "1) Register" << endl;
                cout << "2) Login" << endl;
                cout << "==============================================" << endl;
                cout << YELLOW << "[?] Enter choice[1-2]: " << RESET;
                cin >> subUserChoice;
                cin.ignore();
                switch (subUserChoice)
                {
                    case '1':
                    
                        cout << endl;
                        if (userRegister()){
                            cout << endl;
                            cout << GREEN << "[+] Great! Now Login" << RESET << endl;
                            cout << endl;
                        }else{
                            cout << RED << "[-] Try Again" << RESET << endl;
                            cout << endl;
                        };
                        goto userRegisterLoginMenu;
                        break;
                    case '2':
                        if (!userLogin()){
                            cout << RED << "[-] Try Again" << RESET << endl;
                            cout << endl;
                            goto userRegisterLoginMenu;
                        };
                        userFeatureMenu:
                            cout << endl;
                            cout << "==============================================" << endl;
                            cout << "What do u want to do?" << endl;
                            cout << "1) Browse Products" << endl;
                            cout << "2) Search Products" << endl;
                            cout << "3) View Cart" << endl;
                            cout << "4) Add To Cart" << endl;
                            cout << "5) Remove From Cart" << endl;
                            cout << "6) View Wishlist" << endl;
                            cout << "7) Add To Wishlist" << endl;
                            cout << "8) Remove From Wishlist" << endl;
                            cout << "9) Checkout" << endl;
                            cout << "A) Get Order History And Provide Feedback" << endl;
                            cout << "B) Make Support Reqeust" << endl;
                            cout << "C) View Past Support Requests" << endl;
                            cout << "D) See Notifications" << endl;
                            cout << "E) Exit" << endl;
                            char userFeatureChoice;
                            cout << "==============================================" << endl;
                            cout << YELLOW << "[?] Enter choice[1-9 OR A-E]: " << RESET;
                            cin >> userFeatureChoice;
                            cin.ignore();
                            switch(userFeatureChoice){
                                case '1':
                                    browseProducts();
                                    goto userFeatureMenu;
                                    break;
                                case '2':
                                    searchProduct();
                                    goto userFeatureMenu;
                                    break;
                                case '3':
                                    viewCart();
                                    goto userFeatureMenu;
                                    break;
                                case '4':
                                    addToCart();
                                    goto userFeatureMenu;
                                    break;
                                case '5':
                                    removeFromCart();
                                    goto userFeatureMenu;
                                    break;
                                case '6':
                                    viewWishlist();
                                    goto userFeatureMenu;
                                    break;
                                case '7':
                                    addToWishlist();
                                    goto userFeatureMenu;
                                    break;
                                case '8':
                                    removeFromWishlist();
                                    goto userFeatureMenu;
                                    break;
                                case '9':
                                    checkout();
                                    goto userFeatureMenu;
                                    break;
                                case 'A':
                                    getOrderHistoryAndProvideFeedback();
                                    goto userFeatureMenu;
                                    break;
                                case 'B':
                                    makeSupportRequest();
                                    goto userFeatureMenu;
                                    break;
                                case 'C':
                                    viewPastSupportRequests();
                                    goto userFeatureMenu;
                                    break;
                                case 'D':
                                    getNotifications();
                                    goto userFeatureMenu;
                                    break;
                                case 'E':
                                    cout << GREEN << "[+] Exiting...Goodbye" << RESET << endl;
                                    return 0;
                                default:
                                    cout << RED << "[-] Invalid Choice" << RESET << endl;
                                    goto userFeatureMenu;
                                }

                        break;

                    default:
                        cout << RED << "[-] Invalid Choice" << RESET << endl;
                        goto userRegisterLoginMenu;
                    }
            break;
            case '2':
                employeeRegisterLoginMenu:
                    char subEmployeeChoice;
                    cout << endl;
                    cout << "Employee Login" << endl;
                    cout << "1) Register" << endl;
                    cout << "2) Login" << endl;
                    cout << "==============================================" << endl;
                    cout << YELLOW << "[?] Enter choice[1-2]: " << RESET;
                    cin >> subEmployeeChoice;
                    cin.ignore();
                    switch (subEmployeeChoice)
                    {
                        case '1':
                            if (employeeRegister()){
                                cout << GREEN << "[+] Great! Now Login" << RESET << endl;
                            }else{
                                cout << RED << "[-] Try Again" << RESET << endl;
                            };
                            goto employeeRegisterLoginMenu;
                            break;
                        case '2':
                            if (!employeeLogin()){
                                cout << RED << "[-] Try Again" << RESET << endl;
                                goto employeeRegisterLoginMenu;
                            };
                            employeeFeatureMenu:
                                cout << "==============================================" << endl;
                                cout << "What do you want to do?" << endl;
                                cout << "1) Manage Support Requests" << endl;
                                cout << "2) Manage Inventory" << endl;
                                cout << "3) Alerts" << endl;
                                cout << "4) Get Employee Contributions (Ranking)" << endl;
                                cout << "5) Manage Feedback" << endl;
                                cout << "6) Send Announcement" << endl;
                                cout << "7) Exit" << endl;
                                char employeeFeatureChoice;
                                cout << "==============================================" << endl;
                                cout << YELLOW << "[?] Enter choice [1-6]: " << RESET;
                                cin >> employeeFeatureChoice;
                                cin.ignore();
                                switch (employeeFeatureChoice)
                                {
                                    case '1':
                                        respondToSupportRequest();
                                        goto employeeFeatureMenu;
                                        break;
                                    case '2':
                                        inventoryManagement();
                                        goto employeeFeatureMenu;
                                        break;
                                    case '3':
                                        alertEmployee();
                                        goto employeeFeatureMenu;
                                        break;
                                    case '4':
                                        getEmployeeContributions();
                                        goto employeeFeatureMenu;
                                        break;
                                    case '5':
                                        respondToFeedback();
                                        goto employeeFeatureMenu;
                                        break;
                                    case '6':
                                        sendNotification();
                                        goto employeeFeatureMenu;
                                        break;
                                    case '7':
                                        cout << GREEN << "[+] Exiting...Goodbye!" << RESET << endl;
                                        return 0;
                                    default:
                                        cout << RED << "[-] Invalid Choice" << RESET << endl;
                                        goto employeeFeatureMenu;
                                        break;
                                }
                    }
                break;

                case '3':
                    adminLoginMenu:
                        cout << endl;
                        cout << "Admin Login" << endl;
                        if (!adminLogin()) {
                            cout << RED << "[-] Try Again" << RESET << endl;
                            goto adminLoginMenu;
                        }
                        adminFeatureMenu:
                            cout << "==============================================" << endl;
                            cout << "What do you want to do?" << endl;
                            cout << "1) Manage Users/Employee/Admin" << endl;
                            cout << "2) Manage Products" << endl;
                            cout << "3) Bulk Import/Export Products" << endl;
                            cout << "4) Manage Discount Codes" << endl;
                            cout << "5) Get Unusual Login Attempts Logs" << endl;
                            cout << "6) Generate Sales Report" << endl;
                            cout << "7) Send Announcement" << endl;
                            cout << "8) Exit" << endl;
                            cout << "==============================================" << endl;
                            char adminFeatureChoice;
                            cout << YELLOW << "[?] Enter choice[1-7]: " << RESET;
                            cin >> adminFeatureChoice;
                            cin.ignore();
                            switch (adminFeatureChoice) {
                                case '1':
                                    userManagement();
                                    goto adminFeatureMenu;
                                    break;
                                case '2':
                                    inventoryManagement();
                                    goto adminFeatureMenu;
                                    break;
                                case '3':
                                    bulkImportAndExport();
                                    goto adminFeatureMenu;
                                    break;
                                case '4':
                                    manageDiscountCodes();
                                    goto adminFeatureMenu;
                                    break;
                                case '5':
                                    displayActivityLogs();
                                    goto adminFeatureMenu;
                                    break;
                                case '6':
                                    listAndChooseFolder();
                                    goto adminFeatureMenu;
                                    break;
                                case '7':
                                    sendAdminNotification();
                                    goto adminFeatureMenu;
                                    break;
                                case '8':
                                    cout << GREEN << "[+] Exiting...Goodbye" << RESET << endl;
                                    return 0;
                                default:
                                    cout << RED << "[-] Invalid Choice" << RESET << endl;
                                    goto adminFeatureMenu;
                                    break;
                            }
                    break;
                default:
                    cout << RED << "[-] Invalid Choice" << RESET << endl;
                    goto userRoleMenu;
            }

    return 0;
}
