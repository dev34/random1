#ifndef ADMIN_H
#define ADMIN_H
#include "project.h"

void sendAdminNotification();
void storeOTP(int otp);
bool verifyOTP(int enteredOTP);
int adminLogin();
void addUser(const char filepath[], const char username[], char password[]);
void removeUser(const char filepath[], const char username[]);
void viewUsers(const char filepath[]);
void userManagement();
void bulkImportAndExport();
bool productExistsInProductFile(char input_productID[]);
void manageDiscountCodes();
void displayActivityLogs();
int findProduct(char** productNames, int productCount, const char* name);
void summarizeOrderFile(const char* filePath, char**& productNames, int*& quantities, int*& revenues, int*& productIds, char**& productCategories, int& productCount);
void generateSalesReport(const char* folderPath);
void listAndChooseFolder();


#endif