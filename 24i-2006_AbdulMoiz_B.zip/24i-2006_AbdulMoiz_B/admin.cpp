#include "admin.h"
using namespace std;

char global_adminname[30];
bool global_isOwner = false;

void sendAdminNotification(){ 
    char username[30];
    char msg[500];
    fstream notificationFileHandle("notifications.txt",ios::app);
    cout << YELLOW << "[?] Enter username: " << RESET;
    cin.getline(username,30);

    if (!(usernameAlreadyExists(username,"users.txt"))){
        cout << RED << "[-] Username does not exist...exiting!" << RESET << endl;
        return;
    }
    cout << YELLOW << "[?] Enter message: " << RESET;
    cin.getline(msg,500);

    notificationFileHandle << username << "|" << msg << endl;
    cout << GREEN << "[+] Notification has been pushed successfully" << RESET << endl;
    notificationFileHandle.close();

}

int generateOTP() {
    srand(time(0));  
    int otp = rand() % (999999)+1;  //restrict to 6 digit
    if (otp < 100000){ //if 5 digit --> 6 digit
        otp += 100000;
    }
    return otp;
}

void storeOTP(int otp) {
    fstream otpFileHandle("otp.txt", ios::out);
    if (otpFileHandle.is_open()) {
        otpFileHandle << otp << endl;
        otpFileHandle.close();
    } else {
        cout << RED << "[-] Error: Unable to write OTP to file." << RESET << endl;
    }
}

bool verifyOTP(int enteredOTP) {
    fstream otpFileHandle("otp.txt", ios::in);
    int storedOTP;
    if (otpFileHandle.is_open()) {
        otpFileHandle >> storedOTP;
        otpFileHandle.close();
        return (enteredOTP == storedOTP);  
    } else {
        cout << RED << "[-] Error: OTP file not found." << RESET << endl;
        return false;
    }
}

int adminLogin() {
    char input_username[30];
    char input_password[30];

    cout << YELLOW << "[?] Enter username: " << RESET;
    cin.getline(input_username, 30);
    if (getLength(input_username) > 30) {
        cout << RED << "[-] Username must be less than 30 characters" << RESET << endl;
        return false;
    }
    if (myFind(' ', input_username)) {
        cout << RED << "[-] Username cannot contain spaces" << RESET << endl;
        return false;
    }

    cout << YELLOW << "[?] Enter password: " << RESET;
    cin.getline(input_password, 30);
    if (getLength(input_password) > 30) {
        cout << RED << "[-] Password must be less than 30 characters" << RESET << endl;
        return false;
    }
    if (myFind(' ', input_password)) {
        cout << RED << "[-] Password cannot contain spaces" << RESET << endl;
        return false;
    }

    fstream userFileHandle("admins.txt", ios::in);
    char stored_username[30];
    char stored_password[30];

    if (userFileHandle.is_open()) {
        while (userFileHandle >> stored_username >> stored_password) {
            if ((areEqual(stored_username, input_username)) && (hashText(input_password) == stoull(stored_password))) {

                cout << GREEN << "[+] Login Successful, please enter the OTP sent to you" << endl;
                cout << RESET;

                int otp = generateOTP();
                cout << "The otp is: " << otp << endl;
                storeOTP(otp);

                int enteredOTP;
                cout << YELLOW << "[?] Enter OTP: " << RESET;
                cin >> enteredOTP;

                if (verifyOTP(enteredOTP)) {
                    cout << GREEN << "[+] OTP Verified Successfully!" << endl;
                    cout << RESET;
                    myStrcpy(global_adminname, stored_username);
                    if (areEqual(stored_username, "admin")) {//if username is admin it is user
                        global_isOwner = true;
                        cout << GREEN << "[+] Shop Owner Detected!" << endl;
                        cout << RESET;
                    }
                    userFileHandle.close();
                    return true;
                } else {
                    cout << RED << "[-] Invalid OTP!" << endl;
                    cout << RESET;
                    userFileHandle.close();
                    return false;
                }
            }
        }
    }
    userFileHandle.close();
    fstream activityLogFileHandle("activityLogs.txt",ios::app);
    time_t currentTime = time(0);
    activityLogFileHandle << input_username << " " <<input_password << " " << currentTime << " 2" << endl;
    activityLogFileHandle.close();
    cout << RED << "[-] Login Failed" << endl;
    cout << RESET;
    return false;
}

void addUser(const char filepath[], const char username[], char password[]) {
    fstream userFileHandle(filepath, ios::app);
    userFileHandle << username << " " << hashText(password) << endl;
    userFileHandle.close();
}

void removeUser(const char filepath[], const char username[]) {
    fstream userFileHandle(filepath, ios::in);
    fstream tempFileHandle("temp.txt", ios::out);

    char read_username[30];
    char read_pass[30];

    while (userFileHandle >> read_username >> read_pass) {
        if (!(areEqual(read_username, username))) {
            tempFileHandle << read_username << " " << read_pass << endl;
        }
    }

    userFileHandle.close();
    tempFileHandle.close();
    remove(filepath);
    rename("temp.txt", filepath);
}

void viewUsers(const char filepath[]) {
    fstream userFileHandle(filepath, ios::in);
    char read_username[30];
    char read_pass[30];

    cout << "Users List:" << endl;
    while (userFileHandle >> read_username >> read_pass) {
        cout << "Username: " << read_username << ", Password: " << read_pass << endl;
    }
    userFileHandle.close();
}

void userManagement() {
    cout << "Manage?" << endl;
    cout << "1) Admin" << endl;
    cout << "2) Employee" << endl;
    cout << "3) Customer" << endl;

    char roleChoice;
    cout << YELLOW << "[?] Enter a choice[1-3]: " << RESET;
    cin >> roleChoice;
    cin.ignore(); 

    if (roleChoice == '1') {
        cout << "Select action you want to perform: " << endl;
        cout << "1) View Admins" << endl;
        cout << "2) Add Admins" << endl;
        cout << "3) Remove Admins" << endl;
        cout << YELLOW << "[?] Enter choice[1-3]: " << RESET;
        char operationChoice;
        cin >> operationChoice;
        cin.ignore();

        if (operationChoice == '1') {

            viewUsers("admins.txt");

        } else if (operationChoice == '2') {

            if (!(global_isOwner)) {
                cout << RED << "[-] You must be a store owner for this action" << RESET << endl;
                return;
            }

            char newAdminUsername[30];
            char newAdminPassword[30];

            cout << YELLOW << "[?] Enter new admin username: " << RESET;
            cin.ignore();
            cin.getline(newAdminUsername,30);

            if (myFind(' ', newAdminUsername)) {
                cout << RED << "[-] Error: Username cannot contain spaces!" << RESET << endl;
                return;
            }

            if (usernameAlreadyExists(newAdminUsername, "admins.txt")) {
                cout << RED << "[-] Admin username already exists!" << RESET << endl;
                return;
            }

            cout << YELLOW << "[?] Enter new admin password: " << RESET;
            cin.getline(newAdminPassword,30);

            if (myFind(' ', newAdminPassword)) {
                cout << RED << "[-] Error: Password cannot contain spaces!" << RESET << endl;
                return;
            }

            addUser("admins.txt", newAdminUsername, newAdminPassword);

            cout << GREEN << "[+] Admin added successfully!" << RESET << endl;

        } else if (operationChoice == '3') {

            if (!(global_isOwner)) {
                cout << RED << "[-] You must be a store owner for this action" << RESET << endl;
                return;
            }

            char adminToRemove[30];
            cout << YELLOW << "[?] Enter admin username to remove: " << RESET;
            cin >> adminToRemove;

            if (!usernameAlreadyExists(adminToRemove, "admins.txt")) {
                cout << RED << "[-] Admin not found!" << RESET << endl;
                return;
            }

            removeUser("admins.txt", adminToRemove);

            cout << GREEN << "[+] Admin removed successfully!" << RESET << endl;

        }

    } else if (roleChoice == '2') {

        cout << "Select action you want to perform: " << endl;
        cout << "1) View Employees" << endl;
        cout << "2) Add Employee" << endl;
        cout << "3) Remove Employee" << endl;
        cout << YELLOW << "[?] Enter choice[1-3]: " << RESET;
        char operationChoice;
        cin >> operationChoice;
        cin.ignore();

        if (operationChoice == '1') {

            viewUsers("employees.txt");

        } else if (operationChoice == '2') {

            char newEmployeeUsername[30];
            char newEmployeePassword[30];

            cout << YELLOW << "[?] Enter new employee username: " << RESET;
            cin.ignore();
            cin.getline(newEmployeeUsername,30);

            if (myFind(' ', newEmployeeUsername)) {
                cout << "Error: Username cannot contain spaces!" << endl;
                return;
            }

            if (usernameAlreadyExists(newEmployeeUsername, "employees.txt")) {
                cout << RED << "[-] Employee username already exists!" << RESET << endl;
                return;
            }

            cout << YELLOW << "[?] Enter new employee password: " << RESET;
            cin.getline(newEmployeePassword, 30);

            if (myFind(' ', newEmployeePassword)) {
                cout << "Error: Password cannot contain spaces!" << endl;
                return;
            }

            addUser("employees.txt", newEmployeeUsername, newEmployeePassword);
            fstream salesReportFileHandle("salesReport.txt",ios::app);
            salesReportFileHandle << newEmployeeUsername << " 0" << endl;

            cout << GREEN << "[+] Employee added successfully!" << RESET << endl;

        } else if (operationChoice == '3') {

            char employeeToRemove[30];
            cout << YELLOW << "[?] Enter employee username to remove: " << RESET;
            cin >> employeeToRemove;

            if (!usernameAlreadyExists(employeeToRemove, "employees.txt")) {
                cout << RED << "[-] Employee not found!" << RESET << endl;
                return;
            }

            removeUser("employees.txt", employeeToRemove);

            cout << GREEN << "[+] Employee removed successfully!" << RESET << endl;
        }

    } else if (roleChoice == '3') {

        cout << "Select action you want to perform: " << endl;
        cout << "1) View Customers" << endl;
        cout << "2) Add Customer" << endl;
        cout << "3) Remove Customer" << endl;
        cout << YELLOW << "[?] Enter choice[1-3]: " << RESET;
        char operationChoice;
        cin >> operationChoice;
        cin.ignore();

        if (operationChoice == '1') {

            viewUsers("users.txt");

        } else if (operationChoice == '2') {

            char newCustomerUsername[30];
            char newCustomerPassword[30];

            cout << YELLOW << "[?] Enter new customer username: " << RESET;
            cin.ignore();
            cin.getline(newCustomerUsername,30);

            if (myFind(' ', newCustomerUsername)) {
                cout << "Error: Username cannot contain spaces!" << endl;
                return;
            }

            if (usernameAlreadyExists(newCustomerUsername, "users.txt")) {
                cout << RED << "[-] Customer username already exists!" << RESET << endl;
                return;
            }

            cout << YELLOW << "[?] Enter new customer password: " << RESET;
            cin.getline(newCustomerPassword,30);

            if (myFind(' ', newCustomerPassword)) {
                cout << "Error: Password cannot contain spaces!" << endl;
                return;
            }

            addUser("users.txt", newCustomerUsername, newCustomerPassword);

            cout << GREEN << "[+] Customer added successfully!" << RESET << endl;

        } else if (operationChoice == '3') {

            char customerToRemove[30];
            cout << YELLOW << "[?] Enter customer username to remove: " << RESET;
            cin >> customerToRemove;

            if (!usernameAlreadyExists(customerToRemove, "users.txt")) {
                cout << RED << "[-] Customer not found!" << RESET << endl;
                return;
            }

            removeUser("users.txt", customerToRemove);

            cout << GREEN << "[+] Customer removed successfully!" << RESET << endl;
        }
    }
}

void bulkImportAndExport(){ //for plus we add to quantity(import), and for minus we subtract from quantity(export)
    browseProductsSortedByAvailibilty();
    int productID;
    cout << YELLOW << "[?] Enter productID: " << endl;
    cout << RESET;
    cin >> productID;
    if (!productExists(productID)){
        cout << RED << "[-] Invalid Product ID" << endl;
        cout << RESET;
        return;
    }
    cout << YELLOW << "[?] How many items do you want to import/export? (use minus sign for exporting)" << RESET;
    int new_quantity;
    cout << YELLOW << "[?] No. of items? ";
    cout << RESET;
    cin >> new_quantity;
    fstream productFileHandle("products.txt",ios::in);
    fstream tempFileHandle("products_temp.txt",ios::app);

    int id;
    char name[30];
    int price;
    int quantity;
    char category[30];

    if (productFileHandle.is_open()){
        int calculated_quantity;

        while(productFileHandle>>id>>name>>price>>quantity>>category){
        if (productID == id){
                calculated_quantity = (quantity+new_quantity);
                if (calculated_quantity < 0){
                    cout << RED << "[-] You cannot export more than the amount of product available" << endl;
                    cout << RESET;
                    productFileHandle.close();
                    tempFileHandle.close();
                    remove("products_temp.txt");
                    return;
                }
                tempFileHandle << id << " " << name << " " << price << " "<< calculated_quantity << " " << category << endl; 
                continue;
        }
        tempFileHandle << id << " " << name << " " << price << " "<< quantity << " " << category << endl; 

        }

    }

    productFileHandle.close();
    tempFileHandle.close();
    remove("products.txt");
    rename("products_temp.txt", "products.txt");
    cout << GREEN << "[+] Thie item has been successfully updated" << RESET << endl;

}

bool productExistsInProductFile(char input_productID[]){
    char orderFilePath[50]="products.txt";

    char id[5];
    char name[30];
    int price;
    int quantity;
    char category[30];

    fstream orderFileHandle(orderFilePath,ios::in);
    if (orderFileHandle.is_open()){
        while(orderFileHandle>>id>>name>>price>>quantity>>category){
            if (areEqual(id,input_productID)){
                orderFileHandle.close();
                return true;
            }

        }
        orderFileHandle.close();
        return false;
    }
    return false;
}

void manageDiscountCodes() {
    cout << "Select action you want to perform: " << endl;
    cout << "1) View Discount Codes" << endl;
    cout << "2) Add Discount Code" << endl;
    cout << "3) Remove Discount Code" << endl;

    char operationChoice;
    cin >> operationChoice;
    cin.ignore(); 

    if (operationChoice == '1') {

        fstream discountFile("discount_codes.txt", ios::in);
        if (!discountFile.is_open()) {
            cout << "Failed to open discount codes file!" << endl;
            return;
        }

        char code[30];
        char productIds[100];
        int discount;

        cout << "Discount Codes: " << endl;
        //format code|productId1,productId2,...|discount%
        while (discountFile >> code >> productIds >> discount) {
            cout << "Code: " << code << " | Product IDs: " << productIds << " | Discount: " << discount << "%" << endl;
        }
        discountFile.close();
    } else if (operationChoice == '2') {

        char newCode[30];
        char newProductIds[100];  
        int newDiscount;

        cout << YELLOW << "[?] Enter new discount code: " << RESET;
        cin.getline(newCode, 30);

        if (myFind(' ', newCode)) {
            cout << RED << "[-] Error: Discount code cannot contain spaces!" << RESET << endl;
            return;
        }

        int numProducts;
        cout << YELLOW << "[?] Enter the number of products for the discount code: " << RESET;
        cin >> numProducts;
        cin.ignore(); 

        char** productIds = new char*[numProducts];
        for (int i = 0; i < numProducts; i++) {
            productIds[i] = new char[30];  
            cout << YELLOW << "[?] Enter product ID " << i + 1 << ": " << RESET;
            cin.getline(productIds[i], 30);

            if (!productExistsInProductFile(productIds[i])) {
                cout << RED << "[-] Error: Product ID " << productIds[i] << " does not exist!" << RESET <<endl;

                for (int j = 0; j <= i; j++) {
                    delete[] productIds[j];
                }
                delete[] productIds;
                return;
            }
        }

        cout << YELLOW << "[?] Enter the discount percentage: " << RESET;
        cin >> newDiscount;
        cin.ignore(); 

        fstream discountFile("discount_codes.txt", ios::app);
        if (!discountFile.is_open()) {
            cout << "Failed to open discount codes file!" << endl;

            for (int i = 0; i < numProducts; i++) {
                delete[] productIds[i];
            }
            delete[] productIds;
            return;
        }

        discountFile << newCode << " ";

        for (int i = 0; i < numProducts; i++) {
            discountFile << productIds[i];
            if (i < numProducts - 1) discountFile << ",";
            delete[] productIds[i];
        }
        delete[] productIds;

        discountFile << " " << newDiscount << endl;
        discountFile.close();

        cout << GREEN << "[+] Discount code added successfully!" << RESET << endl;
    } else if (operationChoice == '3') {

        char codeToRemove[30];
        cout << YELLOW << "[?] Enter discount code to remove: " << RESET;
        cin.getline(codeToRemove, 30);

        fstream discountFile("discount_codes.txt", ios::in);
        fstream tempFile("temp_discount_codes.txt", ios::out);

        if (!discountFile.is_open() || !tempFile.is_open()) {
            cout << "Failed to open discount codes file!" << endl;
            return;
        }

        bool removed = false;
        char code[30];
        char productIds[100];
        int discount;
        while (discountFile >> code >> productIds >> discount) {
            if (areEqual(code, codeToRemove)) {
                removed = true;
            } else {
                tempFile << code << " " << productIds << " " << discount << endl;
            }
        }

        discountFile.close();
        tempFile.close();
        remove("discount_codes.txt");
        rename("temp_discount_codes.txt", "discount_codes.txt");

        if (removed) {
            cout << GREEN << "[+] Discount code removed successfully!" << RESET << endl;
        } else {
            cout << RED << "[-] Discount code not found!" << RESET << endl;
        }
    }
}

void displayActivityLogs() {
    //for checking failed login attempts
    ifstream logFile("activityLogs.txt",ios::in);

    if (!logFile.is_open()) {
        cout << "Error: Could not open log file!" << endl;
        return;
    }

    cout << setw(20) << left << "Username" 
         << setw(20) << left << "Password"
         << setw(15) << left << "Role"
         << setw(50) << left << "Date" << endl;

    char username[30], password[30];
    time_t timestamp;
    int roleID;
    while (logFile >> username >> password >> timestamp >> roleID) {

        cout << setw(20) << left << username
             << setw(20) << left << password;

             if (roleID == 0){
                cout <<  setw(15) << left <<"Customer";
             }
             else if (roleID == 1){
                cout << setw(15) << left <<"Employee" ;
             }else{
                cout <<setw(15) << left << "Admin";
             }
             cout << setw(10) << left << formatCurrentTimeToYear(timestamp) << " " << formatCurrentTimeToHour(timestamp) << endl;
    }

    logFile.close();
}

int findProduct(char** productNames, int productCount, const char* name) {
    for (int i = 0; i < productCount; i++) {
        if (areEqual(productNames[i], name)) {
            return i; 
        }
    }
    return -1; 
}


void summarizeOrderFile(const char* filePath, char**& productNames, int*& quantities, int*& revenues, int*& productIds, char**& productCategories, int& productCount) {
    ifstream file(filePath);
    if (!file.is_open()) {
        cout << "Error: Unable to open file: " << filePath << endl;
        return;
    }

    int id, price, quantity;
    char name[50], category[30];

    while (file >> id >> name >> price >> quantity >> category) {
        int index = findProduct(productNames, productCount, name);
        if (index == -1) {
            char** newProductNames = new char*[productCount + 1];
            int* newQuantities = new int[productCount + 1];
            int* newRevenues = new int[productCount + 1];
            int* newProductIds = new int[productCount + 1];
            char** newProductCategories = new char*[productCount + 1];

            for (int i = 0; i < productCount; i++) {
                newProductNames[i] = productNames[i];
                newQuantities[i] = quantities[i];
                newRevenues[i] = revenues[i];
                newProductIds[i] = productIds[i];
                newProductCategories[i] = productCategories[i];
            }

            delete[] productNames;
            delete[] quantities;
            delete[] revenues;
            delete[] productIds;
            delete[] productCategories;

            productNames = newProductNames;
            quantities = newQuantities;
            revenues = newRevenues;
            productIds = newProductIds;
            productCategories = newProductCategories;

            //append new product
            productNames[productCount] = new char[50];
            myStrcpy(productNames[productCount], name);

            quantities[productCount] = quantity;
            revenues[productCount] = price * quantity;
            productIds[productCount] = id;

            productCategories[productCount] = new char[30];
            myStrcpy(productCategories[productCount], category);

            productCount++;
        } else {
            //update existing product
            quantities[index] += quantity;
            revenues[index] += price * quantity;
        }
    }

    file.close();
}

void generateSalesReport(const char* folderPath) {
    char** productNames = nullptr;
    int* quantities = nullptr;
    int* revenues = nullptr;
    int* productIds = nullptr;
    char** productCategories = nullptr;
    int productCount = 0;

    for (const auto& entry : filesystem::directory_iterator(folderPath)) {
        if (entry.is_regular_file()) {
            //used to get foldernames and then pass to func for processing
            summarizeOrderFile(entry.path().string().c_str(), productNames, quantities, revenues, productIds, productCategories, productCount);
        }
    }

    cout << "Daily Sales Report for " << folderPath << ":\n";
    cout << "------------------------------------------------------------\n";
    cout << left << setw(5) << "ID";
    cout << left << setw(30) << "Name";
    cout << left << setw(10) << "Revenue";
    cout << left << setw(10) << "Quantity";
    cout << "Category" << endl;
    for (int i = 0; i < productCount; i++) {
        cout << left << setw(5) << productIds[i];
        cout << left << setw(30) << productNames[i];
        cout << left << setw(10) << revenues[i]; 
        cout << left << setw(10) << quantities[i];
        cout << productCategories[i] << endl;
    }

    for (int i = 0; i < productCount; i++) {
        delete[] productNames[i];
        delete[] productCategories[i];
    }
    delete[] productNames;
    delete[] quantities;
    delete[] revenues;
    delete[] productIds;
    delete[] productCategories;
}

void listAndChooseFolder() {
    char baseFolder[7] = "orders";

    char** folderPaths = nullptr;
    int folderCount = 0;

    for (const auto& entry : filesystem::directory_iterator(baseFolder)) {
        if (entry.is_directory()) {
            char** newFolderPaths = new char*[folderCount + 1];

            for (int i = 0; i < folderCount; i++) {
                newFolderPaths[i] = folderPaths[i];
            }

            delete[] folderPaths;
            folderPaths = newFolderPaths;

            folderPaths[folderCount] = new char[100];
            myStrcpy(folderPaths[folderCount], entry.path().string().c_str());

            cout << folderCount + 1 << ". " << entry.path().filename().string() << "\n";
            folderCount++;
        }
    }

    if (folderCount == 0) {
        cout << RED << "[-] No order file found" << RESET << endl;
        return;
    }

    int choice;
    cout << YELLOW << "[?] Enter your choice (1-" << folderCount << "): " << RESET;
    cin >> choice;

    if (choice < 1 || choice > folderCount) {
        cout << RED << "[-] Invalid choice. Exiting...\n" << RESET << endl;

        for (int i = 0; i < folderCount; i++) {
            delete[] folderPaths[i];
        }
        delete[] folderPaths;
        return;
    }

    const char* selectedFolder = folderPaths[choice - 1];
    generateSalesReport(selectedFolder);

    for (int i = 0; i < folderCount; i++) {
        delete[] folderPaths[i];
    }
    delete[] folderPaths;
}