#include "employee.h"
using namespace std;

char global_employeename[30];

const int threshold_stock = 5;

int employeeLogin(){
    char input_username[30];
    char input_password[30];

    cout << YELLOW << "[?] Enter username: " << RESET;
    cin.getline(input_username,30);
    if (getLength(input_username) > 30){
        cout << RED << "[-] Username must be less than 30 characters" << RESET << endl;
        return false;
    }
    if (myFind(' ',input_username)){
        cout << RED << "[-] Username cannot contain spaces" << RESET << endl;
        return false;
    }

    cout << YELLOW << "[?] Enter password: " << RESET;
    cin.getline(input_password,30);
    if (getLength(input_password) > 30){
        cout << RED << "[-] Password must be less than 30 characters" << RESET << endl;
        return false;
    }
    if (myFind(' ',input_password)){
        cout << RED << "[-] Password cannot contain spaces" << RESET << endl;
        return false;
    }

    fstream userFileHandle("employees.txt",ios::in);
    char stored_username[30]; 
    char stored_password[30];
    if (userFileHandle.is_open()){
        while(userFileHandle>>stored_username>>stored_password){

            if (areEqual(stored_username, input_username) && (hashText(input_password) == stoull(stored_password))){
                myStrcpy(global_employeename, stored_username);
                cout << GREEN << "[+] Login Successful" << endl;
                cout << RESET;
                userFileHandle.close();
                return true;
            }

        }
    }
    userFileHandle.close();
    fstream activityLogFileHandle("activityLogs.txt",ios::app);
    time_t currentTime = time(0);
    activityLogFileHandle << input_username << " " <<input_password << " " << currentTime <<" 1" << endl;
    activityLogFileHandle.close();
    cout << RED << "[-] Login Failed" << endl;
    cout << RESET;
    return false;
}

int employeeRegister(){
    char input_username[30];
    char input_password[30];
    char input_confirmed_password[30];

    cout << YELLOW << "[?] Enter username: " << RESET;
    cin.getline(input_username,30);
    if (getLength(input_username) > 30){
        cout << RED << "[-] Username must be less than 30 characters" << RESET << endl;
        return false;
    }
    if (myFind(' ',input_username)){
        cout << RED << "[-] Username cannot contain spaces" << RESET << endl;
        return false;
    }

    cout << "Enter password: ";
    cin.getline(input_password,30);
    if (getLength(input_password) > 30){
        cout << RED << "[-] Password must be less than 30 characters" << RESET << endl;
        return false;
    }
    if (myFind(' ',input_password)){
        cout << RED << "[-] Password cannot contain spaces" << RESET << endl;
        return false;
    }

    cout << YELLOW << "[?] Confirm password: " << RESET;
    cin.getline(input_confirmed_password,30);

    if (!(areEqual(input_password, input_confirmed_password))){
        cout << RED << "[-] Passwords do not match" << RESET << endl;
        return false;
    }

    if(usernameAlreadyExists(input_username,"employees.txt")){
        cout << RED << "[-] Username already exists" << RESET << endl;
        return false;
    }

    fstream userFileHandle("employees.txt",ios::app);

    if (userFileHandle.is_open()){
        userFileHandle << input_username << " " << hashText(input_password) << endl;
    }
    // add entry to the sales report 
    fstream salesReportFileHandle("salesReport.txt",ios::app);
    salesReportFileHandle << input_username << " 0" << endl;

    userFileHandle.close();
    return true;
}

void findProductById(char id[]) {
    ifstream file("products.txt");
    char currentId[5], price[10], quantity[5];
    char name[50], category[50]; 

    while (file >> currentId) { 
        file >> name >> price >> quantity >> category;

        if (areEqual(currentId,id)) { 
            cout << "Product Name: " << name << endl;
            file.close();
            return;
        }
    }

    cout << "Product name: (N/A)" << endl;
    file.close(); 
}
bool idExistsInFeedback(char id[]) {
    char feedbackID[5];
    char feedbackUsername[30];
    char productID[5];
    char feedbackQuestion[500];
    char feedbackStatus[2];
    char read_employee_name[30];
    char feedbackResponse[500];
    char moveToNextLine[3];

    fstream feedbackFileHandle("feedback.txt", ios::in);

    int count = 0;
    while (feedbackFileHandle.getline(feedbackID, 5, '|')) {
        feedbackFileHandle.getline(feedbackUsername, 30, '|');
        feedbackFileHandle.getline(productID, 5, '|');
        feedbackFileHandle.getline(feedbackQuestion, 500, '|');
        feedbackFileHandle.getline(feedbackStatus, 2, '|');
         if (areEqual(feedbackStatus,"1")){
            feedbackFileHandle.getline(read_employee_name, 30, '|');
            feedbackFileHandle.getline(feedbackResponse, 500);
        }
        else{
            feedbackFileHandle.getline(moveToNextLine,3);
        }
        if ((areEqual(id,feedbackID)) && (areEqual(feedbackStatus,"0"))) {
            feedbackFileHandle.close();
            return true;
        }
    }

    feedbackFileHandle.close();
    return false;
}

bool idExistsInSupport(char id[]) {
    char supportID[5];
    char supportUsername[30];
    char supportQuestion[500];
    char supportStatus[2];
    char readEmployeeName[30];
    char supportResponse[500];
    char moveToNextLine[3];

    fstream supportFileHandle("support.txt", ios::in);

    int count = 0;
    while (supportFileHandle.getline(supportID, sizeof(supportID), '|')) {
        supportFileHandle.getline(supportUsername, sizeof(supportUsername), '|');
        supportFileHandle.getline(supportQuestion, sizeof(supportQuestion), '|');
        supportFileHandle.getline(supportStatus, sizeof(supportStatus), '|');
        if (areEqual(supportStatus, "1")) {
            supportFileHandle.getline(readEmployeeName, sizeof(readEmployeeName),'|');
            supportFileHandle.getline(supportResponse, sizeof(supportResponse));
        }
        else{
            supportFileHandle.getline(moveToNextLine,3);
        }

        if ((areEqual(id,supportID)) && (areEqual(supportStatus,"0"))) {
            supportFileHandle.close();
            return true;
        }
}
    supportFileHandle.close();
    return false;
}

void incrementEmployeeScore(char employeeName[]){
    fstream salesReportFileHandle("salesReport.txt",ios::in);
    fstream salesReportTempFileHandle("salesReport_temp.txt",ios::out);

    char read_employeeName[30];
    char read_score[5];

    while (salesReportFileHandle >> read_employeeName >> read_score){
        if (areEqual(employeeName, read_employeeName)){
            salesReportTempFileHandle << read_employeeName << " " << (atoi(read_score)+1) << endl; 
            continue;
        }
        salesReportTempFileHandle << read_employeeName << " " << read_score << endl; 
    }
    salesReportFileHandle.close();
    salesReportTempFileHandle.close();
    remove("salesReport.txt");
    rename("salesReport_temp.txt","salesReport.txt");
}

void respondToSupportRequest() {
    char supportID[5];
    char supportUsername[30];
    char supportQuestion[500];
    char supportStatus[2];
    char readEmployeeName[30];
    char supportResponse[500];
    char moveToNextLine[3];

    fstream supportFileHandle("support.txt", ios::in);
    if (!supportFileHandle) {
        cout << "Error opening file!" << endl;
        return;
    }

    int count = 0;
    while (supportFileHandle.getline(supportID, sizeof(supportID), '|')) {
        supportFileHandle.getline(supportUsername, sizeof(supportUsername), '|');
        supportFileHandle.getline(supportQuestion, sizeof(supportQuestion), '|');
        supportFileHandle.getline(supportStatus, sizeof(supportStatus), '|');
        if (areEqual(supportStatus, "1")) {
            supportFileHandle.getline(readEmployeeName, sizeof(readEmployeeName),'|');
            supportFileHandle.getline(supportResponse, sizeof(supportResponse));
        }
        else{
            supportFileHandle.getline(moveToNextLine,3);
        }

        if (areEqual(supportStatus, "0")) {
            count++;
            cout << supportID << ") " << supportUsername << ": " << supportQuestion << endl;
        }
    }

    if (count == 0) {
        cout << GREEN << "[+] No pending support requests." << RESET << endl;
        supportFileHandle.close();
        return;
    }

    char choice[5];
    cout << YELLOW << "[?] Enter question ID: " << RESET;
    cin.getline(choice,5);

    if (!idExistsInSupport(choice)) {
        cout << RED << "[-] Invalid choice" << endl;
        cout << RESET;
        return;

    }

    char isMark;
    cout << YELLOW << "[?] Mark this request as resolved (y/N)? " << RESET;
    cin >> isMark;
    if (isMark == 'n' || isMark == 'N'){
        cout << RED << "[-] Nothing changed..." << RESET << endl;
        return;
    }else if (isMark == 'y' || isMark == 'Y'){

        char isEnterResponse;
        cout << YELLOW << "[?] Do you want to enter a response (y/N)? " << RESET;
        cin >> isEnterResponse;
        char enteredResponse[500];
        if (isEnterResponse == 'n' || isEnterResponse == 'N'){
            myStrcpy(enteredResponse,"");
        }else if (isEnterResponse == 'y' || isEnterResponse == 'Y'){

            cout << YELLOW << "[?] Enter your response: " << RESET;
            cin.ignore();
            cin.getline(enteredResponse, 500);
        }
        else{
            cout << RED << "[-] Invalid Choice" << endl;
            cout << RESET;
            return;
        }

        supportFileHandle.clear();
        supportFileHandle.seekg(0, ios::beg);

        fstream supportTempFileHandle("support_temp.txt", ios::out);

    while (supportFileHandle.getline(supportID, sizeof(supportID), '|')) {
        supportFileHandle.getline(supportUsername, sizeof(supportUsername), '|');
        supportFileHandle.getline(supportQuestion, sizeof(supportQuestion), '|');
        supportFileHandle.getline(supportStatus, sizeof(supportStatus), '|');
        if (areEqual(supportStatus, "1")) {
            supportFileHandle.getline(readEmployeeName, sizeof(readEmployeeName),'|');
            supportFileHandle.getline(supportResponse, sizeof(supportResponse));
        }
        else{
            supportFileHandle.getline(moveToNextLine,3);
        }

             if (areEqual(choice,supportID)) {
                supportTempFileHandle << supportID << "|" << supportUsername << "|" << supportQuestion << "|1|" << global_employeename << "|" << enteredResponse << endl;
            } else {
                if (areEqual(supportStatus,"0")){
                    supportTempFileHandle << supportID << "|" << supportUsername << "|" << supportQuestion << "|" <<supportStatus << "|" << endl;
                }else{
                    supportTempFileHandle << supportID << "|" << supportUsername << "|" << supportQuestion << "|" << supportStatus << "|" << readEmployeeName << "|" << supportResponse << endl;
                }
            }
        }

        supportFileHandle.close();
        supportTempFileHandle.close();

        remove("support.txt");
        rename("support_temp.txt", "support.txt");
        incrementEmployeeScore(global_employeename);
        cout << GREEN << "[+] Successful...";
        cout << RESET;
        cout << endl;
    }
    else{
        supportFileHandle.close();
        cout << RED << "[-] Invalid Choice" << endl;
        cout << RESET;
        return;
    }
}

void alertEmployee(){
    int id;
    char name[30];
    int price;
    int quantity;
    char category[30];
    bool isFirstTime = true;
    fstream productFileHandle("products.txt",ios::in);
    if (productFileHandle.is_open()){

        while(productFileHandle>>id>>name>>price>>quantity>>category){
            if (quantity <= threshold_stock){
                if (isFirstTime){
                    cout << RED << "[-] The Following Product Are Low on Stock Plz Restock them Urgently" << RESET << endl;
                    cout << left << setw(5) << "ID";
                    cout << left << setw(30) << "Name";
                    cout << left << setw(10) << "Price";
                    cout << left << setw(10) << "Quantity";
                    cout << "Category" << endl;
                    isFirstTime = false;
                }
                cout << left << setw(5) << id;
                cout << left << setw(30) << name;
                cout << left << setw(10) << price;
                cout << left << setw(10) << quantity;
                cout << category << endl;
            }
        }
    }
    if(isFirstTime){
        cout << GREEN << "[+] No Alerts" << RESET << endl;
    }
    productFileHandle.close();
}

void respondToFeedback() {
    char feedbackID[5];
    char feedbackUsername[30];
    char productID[5];
    char feedbackQuestion[500];
    char feedbackStatus[2];
    char read_employee_name[30];
    char feedbackResponse[500];

    char moveToNextLine[3];

    fstream feedbackFileHandle("feedback.txt", ios::in);

    int count = 0;
    while (feedbackFileHandle.getline(feedbackID, 5, '|')) {
        feedbackFileHandle.getline(feedbackUsername, 30, '|');
        feedbackFileHandle.getline(productID, 5, '|');
        feedbackFileHandle.getline(feedbackQuestion, 500, '|');
        feedbackFileHandle.getline(feedbackStatus, 2, '|');
        if (areEqual(feedbackStatus,"1")){
            feedbackFileHandle.getline(read_employee_name, 30, '|');
            feedbackFileHandle.getline(feedbackResponse, 500);
        }
        else{
            feedbackFileHandle.getline(moveToNextLine,3);
        }

        if (areEqual(feedbackStatus, "0") ) {
            count++;
            findProductById(productID);
            cout << feedbackID << ") " << feedbackUsername << ": " << feedbackQuestion << endl;
            cout << endl;
        }
    }

    if (count == 0) {
        cout << GREEN << "[+] No pending feedback requests." << RESET << endl;
        feedbackFileHandle.close();
        return;
    }

    char choice[5];
    cout << YELLOW << "[?] Enter question ID: " << RESET;
    cin.getline(choice,5);

    if (!idExistsInFeedback(choice)) {
        cout << RED << "[-] Invalid choice" << endl;
        cout << RESET;
        return;

    }
        char enteredResponse[500];

        cout << YELLOW << "[?] Enter your response: " << RESET;
        cin.getline(enteredResponse, 500);

        feedbackFileHandle.clear();
        feedbackFileHandle.seekg(0, ios::beg);

        fstream feedbackTempFileHandle("feedback_temp.txt", ios::out);

    while (feedbackFileHandle.getline(feedbackID, 5, '|')) {
        feedbackFileHandle.getline(feedbackUsername, 30, '|');
        feedbackFileHandle.getline(productID, 5, '|');
        feedbackFileHandle.getline(feedbackQuestion, 500, '|');
        feedbackFileHandle.getline(feedbackStatus, 2, '|');
        if (areEqual(feedbackStatus,"1")){
            feedbackFileHandle.getline(read_employee_name, 30, '|');
            feedbackFileHandle.getline(feedbackResponse, 500);
        }
        else{
            feedbackFileHandle.getline(moveToNextLine,3);
        }

            if (areEqual(choice,feedbackID)) {
                feedbackTempFileHandle << feedbackID << "|" << feedbackUsername << "|" << productID << "|" << feedbackQuestion << "|1|" << global_employeename << "|" << enteredResponse << endl;
            } else {
                if (areEqual(feedbackStatus,"0")){
                    feedbackTempFileHandle << feedbackID << "|" << feedbackUsername << "|" << productID << "|" << feedbackQuestion << "|" << feedbackStatus << "|" << endl;
                }else{
                    feedbackTempFileHandle << feedbackID << "|" << feedbackUsername << "|" << productID << "|" << feedbackQuestion << "|" << feedbackStatus << "|" <<read_employee_name << "|" << feedbackResponse <<  endl;
                }
            }
        }

        feedbackFileHandle.close();
        feedbackTempFileHandle.close();

        remove("feedback.txt");
        rename("feedback_temp.txt", "feedback.txt");
        incrementEmployeeScore(global_employeename);
        cout << GREEN << "[+] Successful...";
        cout << RESET;
        cout << endl;

}

void getEmployeeContributions() {
    // make a score and if feedback,support is given increment the score
    ifstream salesReportFileHandle("salesReport.txt");
    if (!salesReportFileHandle) {
        cout << "Error: Unable to open salesReport.txt" << endl;
        return;
    }

    int total_employees = 0;
    char buffer[100];
    while (salesReportFileHandle.getline(buffer, 100, '\n')) {
        total_employees++;
    }
    salesReportFileHandle.close();

    cout << GREEN << "[+] \nTotal number of employees: "  << total_employees << RESET << endl;

    salesReportFileHandle.open("salesReport.txt");
    char** employeeNames = new char*[total_employees];
    int* scores = new int[total_employees];

    for (int i = 0; i < total_employees; i++) {
        employeeNames[i] = new char[30];
        salesReportFileHandle >> employeeNames[i] >> scores[i];
    }
    salesReportFileHandle.close();

    for (int i = 0; i < total_employees - 1; i++) {
        for (int j = 0; j < total_employees - i - 1; j++) {
            if (scores[j] < scores[j + 1]) {

                swap(scores[j], scores[j + 1]);

                char tempName[30];
                myStrcpy(tempName, employeeNames[j]);
                myStrcpy(employeeNames[j], employeeNames[j + 1]);
                myStrcpy(employeeNames[j + 1], tempName);
            }
        }
    }

    cout << left << setw(30) << "Employee Name" << "Score" << endl;
    for (int i = 0; i < total_employees; i++) {
        cout << left << setw(30) << employeeNames[i] << scores[i] << endl;
    }

    for (int i = 0; i < total_employees; i++) {
        delete[] employeeNames[i];
    }
    delete[] employeeNames;
    delete[] scores;
}

void sendNotification(){
    char username[30];
    char msg[500];
    fstream notificationFileHandle("notifications.txt",ios::app);
    cout << YELLOW << "[?] Enter username: " << RESET;
    cin.getline(username,30);

    if (!(usernameAlreadyExists(username,"users.txt"))){
        cout << RED << "[-] Username does not exist...exiting!" << RESET << endl;
        return;
    }
    cout << YELLOW << "[?] Enter message: " << RESET;
    cin.getline(msg,500);

    notificationFileHandle << username << "|" << msg << endl;
    notificationFileHandle.close();

}